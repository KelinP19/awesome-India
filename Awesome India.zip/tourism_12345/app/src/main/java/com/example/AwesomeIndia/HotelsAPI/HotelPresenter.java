package com.example.AwesomeIndia.HotelsAPI;

import android.app.Activity;

public interface HotelPresenter {

    void onSuccessUpdate(Activity activity, String _studentEmail,  String _eventID, String _eventCategory,
                         String _eventDescription, String _eventTime, String _eventDate, String _eventPriceTicket,
                         String _eventImportPicture, String _Token, String _eventStatus);


}
