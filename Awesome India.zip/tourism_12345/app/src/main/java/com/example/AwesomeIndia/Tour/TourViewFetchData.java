package com.example.AwesomeIndia.Tour;

public interface TourViewFetchData {
    void onUpdateSuccess(TourModule message);

    // we fetch the data from the student pull data then we set it into the student module then we add
    // each module into the jobpostlist

    void onUpdateFailure(String message);
}
