package com.example.AwesomeIndia.models;

import android.location.Location;

public class Tour {

    private String title, description, stay, todo, bestTime, famous;
    private Location location;
    Double latitude;
    Double longitude;
    String id;
    private String diseaseUrl;
    private String key;


    public Tour() {
    }

    public Tour(String title, String description, Double latitude, Double longitude, String diseaseUrl) {
        this.title = title;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
        this.diseaseUrl = diseaseUrl;
    }

    public Tour(String title, String description, String stay, String todo, String bestTime, String famous, Double latitude, Double longitude, String diseaseUrl) {
        this.title = title;
        this.description = description;
        this.stay = stay;
        this.todo = todo;
        this.bestTime = bestTime;
        this.famous = famous;
        this.latitude = latitude;
        this.longitude = longitude;
        this.diseaseUrl = diseaseUrl;
    }

    public String getStay() {
        return stay;
    }

    public void setStay(String stay) {
        this.stay = stay;
    }

    public String getTodo() {
        return todo;
    }

    public void setTodo(String todo) {
        this.todo = todo;
    }

    public String getBestTime() {
        return bestTime;
    }

    public void setBestTime(String bestTime) {
        this.bestTime = bestTime;
    }

    public String getFamous() {
        return famous;
    }

    public void setFamous(String famous) {
        this.famous = famous;
    }

    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDiseaseUrl() {
        return diseaseUrl;
    }

    public void setDiseaseUrl(String diseaseUrl) {
        this.diseaseUrl = diseaseUrl;
    }

}
