package com.example.AwesomeIndia.EventAPI;

import android.app.Activity;

public interface EventPresenterFetchData {

    void onSuccessUpdate(Activity activity);
}
