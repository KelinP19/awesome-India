package com.example.AwesomeIndia.Adapters;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.interfaces.TempleClickListener;

public class HotelAdapter extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView templeTitle;
    public ImageView templeImage, templeDirection;
    public TempleClickListener listener;
    private final Context context;

    public HotelAdapter(@NonNull View itemView) {
        super(itemView);
        context = itemView.getContext();
        templeTitle = itemView.findViewById(R.id.place_name);
        templeImage = itemView.findViewById(R.id.place_imageView);
        templeDirection = itemView.findViewById(R.id.directionMap);
    }

    public void setItemClickListener(TempleClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        listener.onClick(v, getAdapterPosition(),false);
    }
}
