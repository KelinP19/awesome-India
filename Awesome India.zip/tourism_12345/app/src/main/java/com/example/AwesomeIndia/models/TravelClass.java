package com.example.AwesomeIndia.models;

public class TravelClass {
    private String dataTitle;
    private String dataDesc;
    private String dataLang;
    private String to;
    private String date;
    private String time;
    private String dataImage;
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
    public String getDataTitle() {
        return dataTitle;
    }
    public String getDataDesc() {
        return dataDesc;
    }
    public String getDataLang() {
        return dataLang;
    }

    public String getTo() {
        return to;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDataImage() {
        return dataImage;
    }
    public TravelClass(String dataTitle, String dataDesc, String dataLang,String to,String date,String time, String dataImage) {
        this.dataTitle = dataTitle;
        this.dataDesc = dataDesc;
        this.dataLang = dataLang;
        this.to=to;
        this.date=date;
        this.time=time;
        this.dataImage = dataImage;
    }
    public TravelClass(){
    }
}
