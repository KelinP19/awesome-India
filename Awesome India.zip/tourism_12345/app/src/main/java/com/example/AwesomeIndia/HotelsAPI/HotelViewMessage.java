package com.example.AwesomeIndia.HotelsAPI;

public interface HotelViewMessage {

    void onUpdateFailure(String message);
    void onUpdateSuccess(String message);

}
