package com.example.AwesomeIndia.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;
import com.example.AwesomeIndia.Adapters.HotelAdapter;
import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.models.Hotels;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;

public class WhereToStay extends AppCompatActivity {

    private RecyclerView hotels_recyclerView;
    private DatabaseReference hotelDatabaseReference;
    ProgressBar hotelProgressBar;

    private String stuName;
    private String stuEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_where_to_stay);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.stay);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.visit:
                                WhereToStay.this.startActivity(new Intent(WhereToStay.this,
                                        CustomerPanel.class));
                                WhereToStay.this.finish();
                                WhereToStay.this.overridePendingTransition(0, 0);
                            case R.id.travel:
                                WhereToStay.this.startActivity(new Intent(WhereToStay.this,
                                        Traveldashboard.class));
                                WhereToStay.this.finish();
                                WhereToStay.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.stay:
                                return true;
                            case R.id.guide:
                                WhereToStay.this.startActivity(new Intent(WhereToStay.this,
                                        BookGuide.class));
                                WhereToStay.this.finish();
                                WhereToStay.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.query:
                                WhereToStay.this.startActivity(new Intent(WhereToStay.this,
                                        AskQuery.class));
                                WhereToStay.this.finish();
                                WhereToStay.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });

        hotelDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Hotels");
        hotels_recyclerView = findViewById(R.id.hotels_recyclerView);
        hotels_recyclerView.setHasFixedSize(true);
        hotels_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        hotelProgressBar = findViewById(R.id.hotels_progressBar);
        hotelProgressBar.setVisibility(View.VISIBLE);

        hotelLists();
        
    }

    private void hotelLists() {
        FirebaseRecyclerOptions<Hotels> options = new FirebaseRecyclerOptions.Builder<Hotels>()
                .setQuery(hotelDatabaseReference, Hotels.class)
                .build();
        FirebaseRecyclerAdapter<Hotels, HotelAdapter> hotelAdapter = new FirebaseRecyclerAdapter<Hotels,
                HotelAdapter>(options) {
            @NonNull
            @Override
            public HotelAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hotel_card_item, parent,
                        false);
                HotelAdapter holder = new HotelAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull HotelAdapter holder, final int position, @NonNull final Hotels model) {


                hotelProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(WhereToStay.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(WhereToStay.this, HotelDetails.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        hotels_recyclerView.setAdapter(hotelAdapter);
        hotelAdapter.startListening();
    }


    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.requests_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {

        switch (item.getItemId()){
            case R.id.pending_requests:
                Intent intent = new Intent(WhereToStay.this, CustomerHotelList.class);
                intent.putExtra("Email", stuEmail);
                startActivity(intent);
                finish();
                return true;
            case R.id.approved_requests:
                Intent intent2 = new Intent(WhereToStay.this, HotelDashborad.class);
                intent2.putExtra("Email", stuEmail);
                startActivity(intent2);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        stuName = getIntent().getStringExtra("Name");
        stuEmail= getIntent().getStringExtra("Email");
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }
}