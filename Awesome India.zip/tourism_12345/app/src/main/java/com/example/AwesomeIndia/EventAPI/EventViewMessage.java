package com.example.AwesomeIndia.EventAPI;

public interface EventViewMessage {

    void onUpdateFailure(String message);
    void onUpdateSuccess(String message);

}
