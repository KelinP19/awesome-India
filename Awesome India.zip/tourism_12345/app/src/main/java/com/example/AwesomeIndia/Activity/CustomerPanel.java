package com.example.AwesomeIndia.Activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.AwesomeIndia.Adapters.TempleAdapter;
import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.login.LoginPage;
import com.example.AwesomeIndia.models.Report;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;

public class CustomerPanel extends AppCompatActivity {

    public String stuTP,stuDegreeField,stuName, stuEmail, stuPhoneNumber;

    private RecyclerView temple_recyclerView, np_recyclerView, wl_recyclerView, island_recyclerView, museum_recyclerView, child_recyclerView;
//    private TempleAdapter templeAdapter;
//    private TextView view_all_temples;
//
//    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference templeDatabaseReference, npDR, wlDR, iDR, mDR, cDR;
//    ValueEventListener templeEventListener;
//    ArrayList<Report> reports;
//
    ProgressBar templeProgressBar, npProgressBar, wlProgressBar,islandProgressBar, mProgressBar, childProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_panel);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.visit);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.visit:
                                return true;
                            case R.id.travel:
                                Intent intent3 = new Intent(CustomerPanel.this, Traveldashboard.class);
                                intent3.putExtra("Name",stuName);
                                intent3.putExtra("Email", stuEmail);
                                startActivity(intent3);
                                CustomerPanel.this.finish();
                                CustomerPanel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.stay:
                                Intent intent2 = new Intent(CustomerPanel.this, WhereToStay.class);
                                intent2.putExtra("Name",stuName);
                                intent2.putExtra("Email", stuEmail);
                                startActivity(intent2);
                                CustomerPanel.this.finish();
                                CustomerPanel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.guide:
//                                CustomerPanel.this.startActivity(new Intent(CustomerPanel.this,
//                                        BookGuide.class));
                                Intent intent = new Intent(CustomerPanel.this, BookGuide.class);
                                intent.putExtra("Tp", stuTP);
                                intent.putExtra("Degree", stuDegreeField);
                                intent.putExtra("Name",stuName);
                                intent.putExtra("Email", stuEmail);
                                intent.putExtra("PhoneNo", stuPhoneNumber);
                                startActivity(intent);
                                CustomerPanel.this.finish();
                                CustomerPanel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.query:
                                Intent intent1 = new Intent(CustomerPanel.this, AskQuery.class);
                                intent1.putExtra("Tp", stuTP);
                                intent1.putExtra("Name",stuName);
                                intent1.putExtra("Email", stuEmail);
                                intent1.putExtra("PhoneNo", stuPhoneNumber);
                                startActivity(intent1);
                                CustomerPanel.this.finish();
                                CustomerPanel.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });
        

        // fetching the data from the login page
        stuTP = getIntent().getStringExtra("Tp");
        stuDegreeField = getIntent().getStringExtra("Degree");
        stuName = getIntent().getStringExtra("Name");
        stuEmail= getIntent().getStringExtra("Email");
        stuPhoneNumber = getIntent().getStringExtra("PhoneNo");


//        firebaseDatabase = FirebaseDatabase.getInstance();
//
//        templeDatabaseReference = firebaseDatabase.getReference("Temples");
//        temple_recyclerView = findViewById(R.id.temple_recyclerView);
//        temple_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
//        templeProgressBar = findViewById(R.id.temple_progressBar);
//        templeProgressBar.setVisibility(View.VISIBLE);
//        FirebaseRecyclerOptions<Report> options
//                = new FirebaseRecyclerOptions.Builder<Report>()
//                .setQuery(templeDatabaseReference, Report.class)
//                .build();
//        templeProgressBar.setVisibility(View.GONE);
//        templeAdapter = new TempleAdapter(options,this);
//        temple_recyclerView.setAdapter(templeAdapter);

        templeDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Temples");
        temple_recyclerView = findViewById(R.id.temple_recyclerView);
        temple_recyclerView.setHasFixedSize(true);
        temple_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        templeProgressBar = findViewById(R.id.temple_progressBar);
        templeProgressBar.setVisibility(View.VISIBLE);

        npDR = FirebaseDatabase.getInstance().getReference().child("NationalParks");
        np_recyclerView = findViewById(R.id.np_recyclerView);
        np_recyclerView.setHasFixedSize(true);
        np_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        npProgressBar = findViewById(R.id.np_progressBar);
        npProgressBar.setVisibility(View.VISIBLE);

        wlDR = FirebaseDatabase.getInstance().getReference().child("Wildlifes");
        wl_recyclerView = findViewById(R.id.wl_recyclerView);
        wl_recyclerView.setHasFixedSize(true);
        wl_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        wlProgressBar = findViewById(R.id.wl_progressBar);
        wlProgressBar.setVisibility(View.VISIBLE);

        iDR = FirebaseDatabase.getInstance().getReference().child("Islands");
        island_recyclerView = findViewById(R.id.island_recyclerView);
        island_recyclerView.setHasFixedSize(true);
        island_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        islandProgressBar = findViewById(R.id.island_progressBar);
        islandProgressBar.setVisibility(View.VISIBLE);

        mDR = FirebaseDatabase.getInstance().getReference().child("Museums");
        museum_recyclerView = findViewById(R.id.museum_recyclerView);
        museum_recyclerView.setHasFixedSize(true);
        museum_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mProgressBar = findViewById(R.id.museum_progressBar);
        mProgressBar.setVisibility(View.VISIBLE);

        cDR = FirebaseDatabase.getInstance().getReference().child("ChildPark");
        child_recyclerView = findViewById(R.id.childPark_recyclerView);
        child_recyclerView.setHasFixedSize(true);
        child_recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        childProgressBar = findViewById(R.id.childPark_progressBar);
        childProgressBar.setVisibility(View.VISIBLE);

        templeList();
        npLists();
        wlLists();
        islandLists();
        museumLists();
        childParkLists();
    }

    private void museumLists() {
        FirebaseRecyclerOptions<Report> options = new FirebaseRecyclerOptions.Builder<Report>()
                .setQuery(mDR, Report.class)
                .build();
        FirebaseRecyclerAdapter<Report, TempleAdapter> museumAdapter = new FirebaseRecyclerAdapter<Report,
                TempleAdapter>(options) {
            @NonNull
            @Override
            public TempleAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item2, parent,
                        false);
                TempleAdapter holder = new TempleAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull TempleAdapter holder, final int position, @NonNull final Report model) {


                mProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(CustomerPanel.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(CustomerPanel.this, TempleItemDetailsActivity.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        museum_recyclerView.setAdapter(museumAdapter);
        museumAdapter.startListening();
    }

    private void childParkLists() {
        FirebaseRecyclerOptions<Report> options = new FirebaseRecyclerOptions.Builder<Report>()
                .setQuery(cDR, Report.class)
                .build();
        FirebaseRecyclerAdapter<Report, TempleAdapter> childAdapter = new FirebaseRecyclerAdapter<Report,
                TempleAdapter>(options) {
            @NonNull
            @Override
            public TempleAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item, parent,
                        false);
                TempleAdapter holder = new TempleAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull TempleAdapter holder, final int position, @NonNull final Report model) {


                childProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(CustomerPanel.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(CustomerPanel.this, TempleItemDetailsActivity.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        child_recyclerView.setAdapter(childAdapter);
        childAdapter.startListening();
    }

    private void islandLists() {
        FirebaseRecyclerOptions<Report> options = new FirebaseRecyclerOptions.Builder<Report>()
                .setQuery(iDR, Report.class)
                .build();
        FirebaseRecyclerAdapter<Report, TempleAdapter> islandAdapter = new FirebaseRecyclerAdapter<Report,
                TempleAdapter>(options) {
            @NonNull
            @Override
            public TempleAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item1, parent,
                        false);
                TempleAdapter holder = new TempleAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull TempleAdapter holder, final int position, @NonNull final Report model) {


                islandProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(CustomerPanel.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(CustomerPanel.this, TempleItemDetailsActivity.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        island_recyclerView.setAdapter(islandAdapter);
        islandAdapter.startListening();
    }

    private void wlLists() {
        FirebaseRecyclerOptions<Report> options = new FirebaseRecyclerOptions.Builder<Report>()
                .setQuery(wlDR, Report.class)
                .build();
        FirebaseRecyclerAdapter<Report, TempleAdapter> wlAdapter = new FirebaseRecyclerAdapter<Report,
                TempleAdapter>(options) {
            @NonNull
            @Override
            public TempleAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item2, parent,
                        false);
                TempleAdapter holder = new TempleAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull TempleAdapter holder, final int position, @NonNull final Report model) {


                wlProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(CustomerPanel.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(CustomerPanel.this, TempleItemDetailsActivity.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        wl_recyclerView.setAdapter(wlAdapter);
        wlAdapter.startListening();
    }

    private void npLists() {
        FirebaseRecyclerOptions<Report> options = new FirebaseRecyclerOptions.Builder<Report>()
                .setQuery(npDR, Report.class)
                .build();
        FirebaseRecyclerAdapter<Report, TempleAdapter> npAdapter = new FirebaseRecyclerAdapter<Report,
                TempleAdapter>(options) {
            @NonNull
            @Override
            public TempleAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item1, parent,
                        false);
                TempleAdapter holder = new TempleAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull TempleAdapter holder, final int position, @NonNull final Report model) {


                npProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(CustomerPanel.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(CustomerPanel.this, TempleItemDetailsActivity.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        np_recyclerView.setAdapter(npAdapter);
        npAdapter.startListening();
    }

    private void templeList() {
        FirebaseRecyclerOptions<Report> options = new FirebaseRecyclerOptions.Builder<Report>()
                .setQuery(templeDatabaseReference, Report.class)
                .build();
        FirebaseRecyclerAdapter<Report, TempleAdapter> templeAdapter = new FirebaseRecyclerAdapter<Report,
                TempleAdapter>(options) {
            @NonNull
            @Override
            public TempleAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item, parent,
                        false);
                TempleAdapter holder = new TempleAdapter(view);
                return holder;
            }

            @Override
            protected void onBindViewHolder(@NonNull TempleAdapter holder, final int position, @NonNull final Report model) {


                templeProgressBar.setVisibility(View.GONE);
                holder.templeTitle.setText(model.getTitle());
//                holder.newsSource.setText(model.getSource());
                Glide.with(CustomerPanel.this).load(model.getDiseaseUrl()).into(holder.templeImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent postDetailActivity = new Intent(CustomerPanel.this, TempleItemDetailsActivity.class);

                        postDetailActivity.putExtra("title", model.getTitle());
                        postDetailActivity.putExtra("diseaseUrl", model.getDiseaseUrl());
                        postDetailActivity.putExtra("description", model.getDescription());
                        postDetailActivity.putExtra("latitude", model.getLatitude());
                        postDetailActivity.putExtra("longitude", model.getLongitude());
                        postDetailActivity.putExtra("stay", model.getStay());
                        postDetailActivity.putExtra("todo", model.getTodo());
                        postDetailActivity.putExtra("bestTime", model.getBestTime());
                        postDetailActivity.putExtra("famous", model.getFamous());

                        startActivity(postDetailActivity);
                    }
                });

                holder.templeDirection.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", model.getLatitude(), model.getLongitude());
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                        view.getContext().startActivity(intent);
                    }
                });

            }
        };

        temple_recyclerView.setAdapter(templeAdapter);
        templeAdapter.startListening();
    }


    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.actionbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {

        if (item.getItemId() == R.id.logout) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getApplicationContext(), LoginPage.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

//    @Override protected void onStart()
//    {
//        super.onStart();
//        templeAdapter.startListening();
//    }
//
//    // Function to tell the app to stop getting
//    // data from database on stopping of the activity
//    @Override protected void onStop()
//    {
//        super.onStop();
//        templeAdapter.stopListening();
//    }
//
//    @Override
//    public void onTempleItemClick(int position) {
//        Report report = reports.get(position);
//        Intent intent = new Intent(this, TempleItemDetailsActivity.class);
//        intent.putExtra("title", report.getTitle());
//        startActivity(intent);
//    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }


}
