package com.example.AwesomeIndia.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.AwesomeIndia.Adapters.EventListAdapter;
import com.example.AwesomeIndia.EventAPI.EventModule;
import com.example.AwesomeIndia.EventAPI.EventPullData;
import com.example.AwesomeIndia.EventAPI.EventViewFetchData;
import com.example.AwesomeIndia.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Event_list extends AppCompatActivity implements EventViewFetchData {
    private RecyclerView ListDataView;
    private EventListAdapter mPostsAdapter;
    ArrayList<EventModule> eventArrayList = new ArrayList<>();
    private EventPullData eventPullData;
    private static final String TAG = "EventList";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_list_view);
        
        
        ListDataView = findViewById(R.id.EventListView);
        eventPullData = new EventPullData(this,this);
        RecyclerViewMethods();
        eventPullData.onSuccessUpdate(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.manage);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.requests:
                                Event_list.this.startActivity(new Intent(Event_list.this,
                                        AdminPanel.class));
                                Event_list.this.finish();
                                Event_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.travel:
                                Event_list.this.startActivity(new Intent(Event_list.this,
                                        Travel.class));
                                Event_list.this.finish();
                                Event_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.manage:
                                return true;
                            case R.id.add_places:
                                Event_list.this.startActivity(new Intent(Event_list.this,
                                        PlacesActivity.class));
                                Event_list.this.finish();
                                Event_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.all_customers:
                                Event_list.this.startActivity(new Intent(Event_list.this,
                                        Customer_list.class));
                                Event_list.this.finish();
                                Event_list.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });
        
    }

    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new EventListAdapter(this, eventArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }

    // we fetch the data from the student pull data then we set it into the student module then we add
    // each module into the jobpostlist
    @Override
    public void onUpdateSuccess(EventModule message) {
        if(message != null){
            if(message.getEventStatus().equals("Approved")){
                EventModule eventModules = new EventModule();
                eventModules.setStudentID(message.getStudentID());
                eventModules.setStudentEmail(message.getStudentEmail());
                eventModules.setEventID(message.getEventID());
                eventModules.setEventDescription(message.getEventDescription());
                eventModules.setEventCategory(message.getEventCategory());
                eventModules.setEventTime(message.getEventTime());
                eventModules.setEventDate(message.getEventDate());
                eventModules.setEventPriceTicket(message.getEventPriceTicket());
                eventModules.setEventImportPicture(message.getEventImportPicture());
                eventModules.setEventStatus(message.getEventStatus());
                eventArrayList.add(eventModules);
            }
        }
        mPostsAdapter.notifyDataSetChanged();


    }

    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(Event_list.this, message, Toast.LENGTH_LONG).show();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
