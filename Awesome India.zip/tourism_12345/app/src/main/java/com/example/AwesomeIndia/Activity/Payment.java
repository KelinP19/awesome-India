package com.example.AwesomeIndia.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.interfaces.PaymentResultListener;
import com.razorpay.Checkout;

import org.json.JSONException;
import org.json.JSONObject;

public class Payment extends AppCompatActivity implements PaymentResultListener {

    TextView edtamt;
    Button btnpay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        edtamt=(TextView) findViewById(R.id.amountText);
        btnpay=(Button) findViewById(R.id.btnCreateEvent);

        btnpay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(edtamt.getText().toString().isEmpty())
                {
                    Toast.makeText(Payment.this, "Please Enter The Amount.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    int amt = Math.round(Float.parseFloat(edtamt.getText().toString())*100);

                    if(amt<=0)
                    {
                        Toast.makeText(Payment.this, "Please Enter The Valid Amount.", Toast.LENGTH_SHORT).show();
                    }else
                    {
                        Checkout checkout = new Checkout();

                        checkout.setKeyID("rzp_test_WW89pQpTq8DK0R");

                        checkout.setImage(R.drawable.ic_launcher_background);

                        JSONObject object = new JSONObject();

                        try {
                            object.put("name","My Payment");

                            object.put("description","My Test Payment");

                            object.put("currency","INR");

                            object.put("amount",amt);

//                            object.put("prefill.contact", "6359874521");
//
//                            object.put("prefill.email", "mypayment@gmail.com");

                            checkout.open(Payment.this,object);

                        }catch (JSONException e)
                        {
                            e.printStackTrace();
                        }


                    }
                }

            }

        });

    }
    @Override
    public void onPaymentSuccess(String s) {
        Toast.makeText(this, "Payment Successful : "+s, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(this, "Payment Failed : "+s, Toast.LENGTH_SHORT).show();
    }

}