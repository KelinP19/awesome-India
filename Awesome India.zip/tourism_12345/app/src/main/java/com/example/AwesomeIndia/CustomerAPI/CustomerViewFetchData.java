package com.example.AwesomeIndia.CustomerAPI;

public interface CustomerViewFetchData {

    void onUpdateSuccess(CustomerModule message);
    void onUpdateFailure(String message);

}
