package com.example.AwesomeIndia.EventAPI;

public interface EventViewFetchData {

    void onUpdateSuccess(EventModule message);
    void onUpdateFailure(String message);

}
