package com.example.AwesomeIndia.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.AwesomeIndia.Adapters.RequestedHotelsListAdapter;
import com.example.AwesomeIndia.HotelsAPI.HotelModule;
import com.example.AwesomeIndia.HotelsAPI.HotelPullData;
import com.example.AwesomeIndia.HotelsAPI.HotelViewFetchData;
import com.example.AwesomeIndia.R;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class HotelBookinsList extends AppCompatActivity implements HotelViewFetchData {

    private RecyclerView ListDataView;
    private RequestedHotelsListAdapter mPostsAdapter;
    ArrayList<HotelModule> eventArrayList = new ArrayList<>();
    private HotelPullData eventPullData;
    private FirebaseFirestore firebaseFirestore;
    private static final String TAG = "ManageEvent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_bookins_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        ListDataView = findViewById(R.id.EventListView);
        eventPullData = new HotelPullData(this,this);
        RecyclerViewMethods();
        eventPullData.onSuccessUpdate(this);
    }

    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new RequestedHotelsListAdapter(this, eventArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }

    @Override
    public void onUpdateSuccess(HotelModule message) {
        if(message != null){
            if(message.getEventStatus().equals("pending")){
                HotelModule eventModules = new HotelModule();
                eventModules.setStudentEmail(message.getStudentEmail());
                eventModules.setEventID(message.getEventID());
                eventModules.setEventDescription(message.getEventDescription());
                eventModules.setEventCategory(message.getEventCategory());
                eventModules.setEventTime(message.getEventTime());
                eventModules.setEventDate(message.getEventDate());
                eventModules.setEventPriceTicket(message.getEventPriceTicket());
                eventModules.setEventImportPicture(message.getEventImportPicture());
                eventModules.setEventStatus(message.getEventStatus());
                eventModules.setToken(message.getToken());
                eventArrayList.add(eventModules);
            }
        }
        mPostsAdapter.notifyDataSetChanged();

    }


    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(HotelBookinsList.this, message, Toast.LENGTH_LONG).show();
    }


    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.hotel_booking, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {

        if (item.getItemId() == R.id.approved_booking) {
            startActivity(new Intent(HotelBookinsList.this, ApprovedHotelBooking.class));
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}