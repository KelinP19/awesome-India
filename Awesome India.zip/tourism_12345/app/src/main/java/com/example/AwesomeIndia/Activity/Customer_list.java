package com.example.AwesomeIndia.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.AwesomeIndia.Adapters.CustomerListAdapter;
import com.example.AwesomeIndia.CustomerAPI.CustomerFetchData;
import com.example.AwesomeIndia.CustomerAPI.CustomerModule;
import com.example.AwesomeIndia.CustomerAPI.CustomerViewFetchData;
import com.example.AwesomeIndia.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;


public class Customer_list extends AppCompatActivity implements CustomerViewFetchData {
    private RecyclerView ListDataView;
    private CustomerListAdapter mPostsAdapter;
    ArrayList<CustomerModule> studentArrayList = new ArrayList<>();
    private CustomerFetchData studentPullData;
    private static final String TAG = "StudentList";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.all_customers);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.requests:
                                Customer_list.this.startActivity(new Intent(Customer_list.this,
                                        AdminPanel.class));
                                Customer_list.this.finish();
                                Customer_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.travel:
                                Customer_list.this.startActivity(new Intent(Customer_list.this,
                                        Travel.class));
                                Customer_list.this.finish();
                                Customer_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.manage:
                                Customer_list.this.startActivity(new Intent(Customer_list.this,
                                        Event_list.class));
                                Customer_list.this.finish();
                                Customer_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.add_places:
                                Customer_list.this.startActivity(new Intent(Customer_list.this,
                                        PlacesActivity.class));
                                Customer_list.this.finish();
                                Customer_list.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.all_customers:
                                return true;
                        }
                        return false;
                    }
                });
        
        ListDataView = findViewById(R.id.StudentListView);
        studentPullData = new CustomerFetchData(this,this);
        RecyclerViewMethods();
        studentPullData.onSuccessUpdate(this);
    }

    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new CustomerListAdapter(this, studentArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }

// we fetch the data from the student pull data then we set it into the student module then we add
// each module into the jobpostlist
    @Override
    public void onUpdateSuccess(CustomerModule message) {
        if(message != null){
            CustomerModule customerModules = new CustomerModule();
            customerModules.setStudent_Name(message.getStudent_Name());
            customerModules.setStudent_PhoneNumber(message.getStudent_PhoneNumber());
            customerModules.setStudent_Email(message.getStudent_Email());
            customerModules.setStudent_Tp(message.getStudent_Tp());
            customerModules.setStudent_Pass(message.getStudent_Pass());
            customerModules.setStudent_DegreeField(message.getStudent_DegreeField());
            studentArrayList.add(customerModules);

        }
        mPostsAdapter.notifyDataSetChanged();


    }

    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(Customer_list.this, message, Toast.LENGTH_LONG).show();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}