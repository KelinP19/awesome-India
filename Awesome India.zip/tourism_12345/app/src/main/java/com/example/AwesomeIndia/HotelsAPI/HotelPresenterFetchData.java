package com.example.AwesomeIndia.HotelsAPI;

import android.app.Activity;

public interface HotelPresenterFetchData {

    void onSuccessUpdate(Activity activity);
}
