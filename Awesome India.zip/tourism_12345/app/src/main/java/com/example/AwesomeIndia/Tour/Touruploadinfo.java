package com.example.AwesomeIndia.Tour;

import android.app.Activity;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

public class Touruploadinfo implements TourPresenter, TourViewMessage {
    private TourViewMessage eventViewMessage;
    private static final String TAG = "EventImp";


    public Touruploadinfo(TourViewMessage eventViewMessage) {
        this.eventViewMessage = eventViewMessage;
    }

    @Override
    public void onUpdateSuccess(String message) {
        eventViewMessage.onUpdateSuccess(message);
    }

    @Override
    public void onUpdateFailure(String message) {
        eventViewMessage.onUpdateFailure(message);
    }

    // taken from Event presenter
    @Override
    public void onSuccessUpdate(Activity activity, String _studentEmail, String _eventID, String _eventCategory,
                                String _eventDescription, String _eventTime, String _eventDate,
                                String _eventPriceTicket, String _eventImportPicture, String _Token, String _eventStatus)
    {
        TourModule events = new TourModule(_studentEmail, _eventID,_eventCategory,
                _eventDescription, _eventTime, _eventDate, _eventPriceTicket, _eventImportPicture, _Token, _eventStatus);
        FirebaseFirestore.getInstance().collection("TourBookingData").document(_Token)
                .set(events, SetOptions.merge())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            eventViewMessage.onUpdateSuccess("Events has been added ");
                        }else {
                            eventViewMessage.onUpdateFailure("Something went wrong");
                        }
                    }
                });
    }
}
