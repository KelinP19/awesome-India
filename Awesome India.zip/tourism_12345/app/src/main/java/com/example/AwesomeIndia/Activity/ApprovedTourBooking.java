package com.example.AwesomeIndia.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.example.AwesomeIndia.Adapters.TourListAdapter;
import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.Tour.TourModule;
import com.example.AwesomeIndia.Tour.TourPullData;
import com.example.AwesomeIndia.Tour.TourViewFetchData;

import java.util.ArrayList;

public class ApprovedTourBooking extends AppCompatActivity implements TourViewFetchData {

    private RecyclerView ListDataView;
    private TourListAdapter mPostsAdapter;
    ArrayList<TourModule> eventArrayList = new ArrayList<>();
    private TourPullData eventPullData;
    private static final String TAG = "EventList";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_approved_tour_booking);

        ListDataView = findViewById(R.id.EventListView);
        eventPullData = new TourPullData(this,this);
        RecyclerViewMethods();
        eventPullData.onSuccessUpdate(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

    }
    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new TourListAdapter(this, eventArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }




    // we fetch the data from the student pull data then we set it into the student module then we add
    // each module into the jobpostlist
    @Override
    public void onUpdateSuccess(TourModule message) {
        if(message != null){
            if(message.getEventStatus().equals("Approved")){
                TourModule eventModules = new TourModule();
                eventModules.setStudentEmail(message.getStudentEmail());
                eventModules.setEventID(message.getEventID());
                eventModules.setEventDescription(message.getEventDescription());
                eventModules.setEventCategory(message.getEventCategory());
                eventModules.setEventTime(message.getEventTime());
                eventModules.setEventDate(message.getEventDate());
                eventModules.setEventPriceTicket(message.getEventPriceTicket());
                eventModules.setEventImportPicture(message.getEventImportPicture());
                eventModules.setEventStatus(message.getEventStatus());
                eventArrayList.add(eventModules);
            }
        }
        mPostsAdapter.notifyDataSetChanged();


    }



    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(ApprovedTourBooking.this, message, Toast.LENGTH_LONG).show();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}