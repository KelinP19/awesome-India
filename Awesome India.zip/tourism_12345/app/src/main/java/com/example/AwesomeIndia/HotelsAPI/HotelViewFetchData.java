package com.example.AwesomeIndia.HotelsAPI;

public interface HotelViewFetchData {

    void onUpdateSuccess(HotelModule message);
    void onUpdateFailure(String message);

}
