package com.example.AwesomeIndia.models;

public enum MessageType {
    INQUIRY, Issue, COMPLIMENT, Other
}
