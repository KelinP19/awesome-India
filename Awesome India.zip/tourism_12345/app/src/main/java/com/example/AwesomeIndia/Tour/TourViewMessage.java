package com.example.AwesomeIndia.Tour;

public interface TourViewMessage {
    void onUpdateSuccess(String message);

    void onUpdateFailure(String message);
}
