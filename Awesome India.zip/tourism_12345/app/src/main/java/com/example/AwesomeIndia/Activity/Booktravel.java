package com.example.AwesomeIndia.Activity;

import static androidx.constraintlayout.widget.ConstraintLayoutStates.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.AwesomeIndia.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

public class Booktravel extends AppCompatActivity {
    private EditText quantityEditText,eventname,age, n1;
    private TextView amountTextView;
    private Button b1;
    public  String sImageUri, eventID;
    private ImageView imageView;
    public Uri imageUri;
    private static final int PICK_IMAGE_REQUEST = 1;
    private StorageReference storageReference;
    private StorageTask uploadtask;
    private double pricePerItem = 500.00;
    public String stuTP,stuDegreeField,stuName, stuEmail, stuPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booktravel);
        eventname = findViewById(R.id.EditTxtEventCategory);
        age = findViewById(R.id.EditTxtEventTime);
        n1 = findViewById(R.id.EditTxtEventDate);
        imageView = (ImageView) findViewById(R.id.ChosenImage);
        b1=(Button)findViewById(R.id.btnCreateEvent);
        //add amount
        quantityEditText = findViewById(R.id.quantityEditText);
        amountTextView = findViewById(R.id.amountText);

        // Add a TextWatcher to listen for changes in the quantityEditText
        quantityEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not needed for this example
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not needed for this example
            }

            @Override
            public void afterTextChanged(Editable editable) {
                updateAmount();
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name,Age,nu,person;
                name=String.valueOf(eventname.getText());
                Age=String.valueOf(age.getText());
                nu=String.valueOf(n1.getText());
                person=String.valueOf(quantityEditText.getText());
                if(TextUtils.isEmpty(name)){
                    eventname.setError("Your name is required");
                    return;
                }if (TextUtils.isEmpty(Age)){
                    age.setError("Your age is required");
                    return;
                }
                if(TextUtils.isEmpty(nu)){
                    n1.setError("Number is required");
                    return;
                }
                if(TextUtils.isEmpty(person)){
                    quantityEditText.setError("Person is required");
                    return;
                }
                Toast.makeText(Booktravel.this,"Booked!! Let's make payment.",Toast.LENGTH_SHORT).show();
                Intent i=new Intent(Booktravel.this, Payment.class);
                startActivity(i);
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(Booktravel.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(Booktravel.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                } else {
                    PickerImage();
                }
            }
        });
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.visit);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.visit:
                                Intent intent3 = new Intent(Booktravel.this, CustomerPanel.class);
                                intent3.putExtra("Name",stuName);
                                intent3.putExtra("Email", stuEmail);
                                startActivity(intent3);
                                Booktravel.this.finish();
                                Booktravel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.travel:
                                return true;
                            case R.id.stay:
                                Intent intent2 = new Intent(Booktravel.this, WhereToStay.class);
                                intent2.putExtra("Name",stuName);
                                intent2.putExtra("Email", stuEmail);
                                startActivity(intent2);
                                Booktravel.this.finish();
                                Booktravel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.guide:
//                                CustomerPanel.this.startActivity(new Intent(CustomerPanel.this,
//                                        BookGuide.class));
                                Intent intent = new Intent(Booktravel.this, BookGuide.class);
                                intent.putExtra("Tp", stuTP);
                                intent.putExtra("Degree", stuDegreeField);
                                intent.putExtra("Name",stuName);
                                intent.putExtra("Email", stuEmail);
                                intent.putExtra("PhoneNo", stuPhoneNumber);
                                startActivity(intent);
                                Booktravel.this.finish();
                                Booktravel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.query:
                                Intent intent1 = new Intent(Booktravel.this, AskQuery.class);
                                intent1.putExtra("Tp", stuTP);
                                intent1.putExtra("Name",stuName);
                                intent1.putExtra("Email", stuEmail);
                                intent1.putExtra("PhoneNo", stuPhoneNumber);
                                startActivity(intent1);
                                Booktravel.this.finish();
                                Booktravel.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });

    }
    private  void uploadFile(){

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading the image...");
        pd.show();
        Log.d(TAG, "uploadfile: getLastPathSegment type " + imageUri.getLastPathSegment());
        if(imageUri != null){

            StorageReference fileReference =
                    storageReference.child(imageUri.getLastPathSegment());
            uploadtask = fileReference.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    pd.dismiss();
                                    sImageUri = uri.toString();
                                    Log.d(TAG, "uploadFile: url will be upload " + sImageUri);
                                    checkSignUpDetails(sImageUri);
                                    Toast.makeText(Booktravel.this, "Image Upload successful", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Booktravel.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {

                            double progress = (100.0* snapshot.getBytesTransferred()/snapshot.getTotalByteCount());
                            pd.setMessage("Progress: "+ (int) progress + "%");
                        }
                    });

        }else{
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                imageUri = result.getUri();
                Log.d(TAG, "onActivityResult: url is " + imageUri);
                Picasso.with(Booktravel.this).load(result.getUri()).fit().into(imageView);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Log.d(TAG, "onActivityResult: " + error.getMessage().toString());
            }
        }
    }
    private void PickerImage() {
        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .start(Booktravel.this);
    }
    private void checkSignUpDetails(String sImageUri) {

    }
    private void updateAmount() {
        // Get the quantity from the EditText, defaulting to 0 if it's empty or not a valid number
        int quantity = 0;
        try {
            quantity = Integer.parseInt(quantityEditText.getText().toString());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        // Calculate the amount and update the TextView
        double totalAmount = pricePerItem * quantity;
        amountTextView.setText("Amount: " + String.format("%.2f", totalAmount));
    }
    public void onCreateEventByStuBtnClick(View view) {
        if(uploadtask != null && uploadtask.isInProgress()){
            Toast.makeText(Booktravel.this, "Upload in progress", Toast.LENGTH_SHORT).show();
        }
        uploadFile();
    }
}