package com.example.AwesomeIndia.Tour;

import android.app.Activity;

public interface TourPresenterFetchData {
    void onSuccessUpdate(Activity activity);
}
