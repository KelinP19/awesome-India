package com.example.AwesomeIndia.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.Tour.TourViewMessage;
import com.example.AwesomeIndia.Tour.Touruploadinfo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.sql.Timestamp;

public class BookTourActivity extends AppCompatActivity implements TourViewMessage {

    private EditText eventCategory, eventDescription, eventTime, eventDate, eventPriceTicket;
    private String hotelName;
    private int sID;
    private String hotelPrice;
    private String stuName;
    private String stuEmail;
    private String stuPhoneNumber;
    public  String sImageUri, eventID;
    private ImageView imageView;
    public Uri imageUri;
    private static final int PICK_IMAGE_REQUEST = 1;
    private StorageReference storageReference;
    private StorageTask uploadtask;
    private static final String TAG = "AddStudents";
    ProgressDialog mProgressDialog;
    Touruploadinfo eventUploadInfo;

    private double pricePerItem = 2600.00;
    private EditText quantityEditText;
    private TextView amountTextView;

    public BookTourActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_tour);

        hotelName = getIntent().getStringExtra("title");
        hotelPrice = getIntent().getStringExtra("famous");
        checkID();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        eventCategory = findViewById(R.id.EditTxtEventCategory);
        eventCategory.setText(hotelName);
        eventDescription = findViewById(R.id.EditTxtEventDescription);
        eventTime = findViewById(R.id.EditTxtEventTime);
        eventDate = findViewById(R.id.EditTxtEventDate);
        eventPriceTicket= findViewById(R.id.EditTxtEventPriceTicket);
        eventPriceTicket.setText(hotelPrice);

        eventUploadInfo = new Touruploadinfo((TourViewMessage) this);
        imageView = (ImageView) findViewById(R.id.ChosenImage);

        //add amount
        quantityEditText = findViewById(R.id.quantityEditText);
        amountTextView = findViewById(R.id.amountText);

        // Add a TextWatcher to listen for changes in the quantityEditText
        quantityEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not needed for this example
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Not needed for this example
            }

            @Override
            public void afterTextChanged(Editable editable) {
                updateAmount();
            }
        });


        storageReference = FirebaseStorage.getInstance().getReference("UsersImage");

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Please wait..");

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(BookTourActivity.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(BookTourActivity.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                } else {
                    PickerImage();
                }
            }
        });
    }

    private void updateAmount() {
        // Get the quantity from the EditText, defaulting to 0 if it's empty or not a valid number
        int quantity = 0;
        try {
            quantity = Integer.parseInt(quantityEditText.getText().toString());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        // Calculate the amount and update the TextView
        double totalAmount = pricePerItem * quantity;
        amountTextView.setText("Amount: " + String.format("%.2f", totalAmount));
    }

    private void checkID(){
        sID = 0;
        FirebaseFirestore.getInstance().collection("TourBookingData")
                .get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for(int i = 0; i < task.getResult().size(); i++){
                                sID++;
                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(BookTourActivity.this, e.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private  void uploadFile(){

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading the image...");
        pd.show();
        Log.d(TAG, "uploadfile: getLastPathSegment type " + imageUri.getLastPathSegment());
        if(imageUri != null){

            StorageReference fileReference =
                    storageReference.child(imageUri.getLastPathSegment());
            uploadtask = fileReference.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    pd.dismiss();
                                    sImageUri = uri.toString();
                                    Log.d(TAG, "uploadFile: url will be upload " + sImageUri);
                                    checkSignUpDetails(sImageUri);
                                    Toast.makeText(BookTourActivity.this, "Image Upload successful", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(BookTourActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {

                            double progress = (100.0* snapshot.getBytesTransferred()/snapshot.getTotalByteCount());
                            pd.setMessage("Progress: "+ (int) progress + "%");
                        }
                    });

        }else{
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                imageUri = result.getUri();
                Log.d(TAG, "onActivityResult: url is " + imageUri);
                Picasso.with(BookTourActivity.this).load(result.getUri()).fit().into(imageView);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Log.d(TAG, "onActivityResult: " + error.getMessage().toString());
            }
        }
    }
    private void PickerImage() {
        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .start(BookTourActivity.this);
    }


    private void initCreateEvent(String _studentEmail,  String _eventID,String _eventCategory,
                                 String _eventDescription, String _eventTime, String _eventDate,
                                 String _eventPriceTicket, String _eventImportPicture, String _Token, String _eventStatus) {
        mProgressDialog.show();
        eventUploadInfo.onSuccessUpdate(BookTourActivity.this, _studentEmail, _eventID, _eventCategory, _eventDescription
                , _eventTime, _eventDate, _eventPriceTicket, _eventImportPicture, _Token, _eventStatus);
    }
    private void checkSignUpDetails(String imageuri) {
        sID++;
        eventID = Integer.toString(sID);
        String Status = "pending";
        String Category = eventCategory.getText().toString().trim();
        String Description = eventDescription.getText().toString().trim();
        String Time = eventTime.getText().toString().trim();
        String Date = eventDate.getText().toString().trim();
        String Price = eventPriceTicket.getText().toString().trim();
        Log.d(TAG, "checkdetails: url before upload " + imageuri);
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        if(!TextUtils.isEmpty(Category)
                && !TextUtils.isEmpty(Description)
                && !TextUtils.isEmpty(Time)
                && !TextUtils.isEmpty(Date)
                && !TextUtils.isEmpty(Price)){
            initCreateEvent(stuEmail, eventID, Category, Description, Time, Date, Price, imageuri, timestamp.toString(), Status);
        }else{
            if(TextUtils.isEmpty(Category)){
                eventCategory.setError("Your interest is required");
                return;
            }if (TextUtils.isEmpty(Description)){
                eventDescription.setError("Your description is required");
                return;
            }
            if(TextUtils.isEmpty(Time)){
                eventTime.setError("Time is required");
                return;
            }if (TextUtils.isEmpty(Date)){
                eventDate.setError("Date is required");
                return;

            }if (TextUtils.isEmpty(Price)){
                eventPriceTicket.setError("Price is required");
                return;
            }
        }
    }

    @Override
    public void onUpdateSuccess(String message) {
        String name=amountTextView.getText().toString();
        mProgressDialog.dismiss();
        Toast.makeText(BookTourActivity.this, "Booked!! You'll receive call or message any time.", Toast.LENGTH_LONG).show();
        eventCategory.getText().clear();
        eventDescription.getText().clear();
        eventTime.getText().clear();
        eventDate.getText().clear();
        eventPriceTicket.getText().clear();
        imageView.setImageResource(R.drawable.image_add);
        startActivity(new Intent(BookTourActivity.this, Payment.class));
        finish();
//        Intent intent = new Intent(BookHotelActivity.this, CustomerPanel.class);
//        intent.putExtra("Tp", stuTP);
//        intent.putExtra("Degree", stuDegreeField);
//        intent.putExtra("Name",stuName);
//        intent.putExtra("Email", stuEmail);
//        intent.putExtra("PhoneNo", stuPhoneNumber);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();

    }

    @Override
    public void onUpdateFailure(String message) {
        mProgressDialog.dismiss();
        Toast.makeText(BookTourActivity.this, message, Toast.LENGTH_LONG).show();

    }
//
//    @Override
//    public boolean onCreateOptionsMenu( Menu menu ) {
//        getMenuInflater().inflate(R.menu.requests_menu, menu);
//        return super.onCreateOptionsMenu(menu);
//    }
//
//    @Override
//    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {
//
//        switch (item.getItemId()){
//            case R.id.pending_requests:
//                Intent intent = new Intent(BookHotelActivity.this, CustomerEventList.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent.putExtra("title", hotelName);
//                intent.putExtra("famous", hotelPrice);
//                startActivity(intent);
//                finish();
//                return true;
//            case R.id.approved_requests:
//                Intent intent1 = new Intent(BookHotelActivity.this, EventDashborad.class);
//                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                intent1.putExtra("Tp", stuTP);
//                intent1.putExtra("Degree", stuDegreeField);
//                intent1.putExtra("Name",stuName);
//                intent1.putExtra("Email", stuEmail);
//                intent1.putExtra("PhoneNo", stuPhoneNumber);
//                startActivity(intent1);
//                finish();
//                return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        Intent intent = new Intent(Add_event.this, CustomerPanel.class);
//        intent.putExtra("Tp", stuTP);
//        intent.putExtra("Degree", stuDegreeField);
//        intent.putExtra("Name",stuName);
//        intent.putExtra("Email", stuEmail);
//        intent.putExtra("PhoneNo", stuPhoneNumber);
//        startActivity(intent);
        finish();
    }

    public void onCreateEventByStuBtnClick(View view) {
        if(uploadtask != null && uploadtask.isInProgress()){
            Toast.makeText(BookTourActivity.this, "Upload in progress", Toast.LENGTH_SHORT).show();
        }
        uploadFile();
    }

}