package com.example.AwesomeIndia.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;

import com.example.AwesomeIndia.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PlacesActivity extends AppCompatActivity {

    Button temples, childPark, museum, restaurants, hotels, nationalPark,
            wildlife, island, waterfall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.add_places);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.requests:
                                PlacesActivity.this.startActivity(new Intent(PlacesActivity.this,
                                        AdminPanel.class));
                                PlacesActivity.this.finish();
                                PlacesActivity.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.travel:
                                PlacesActivity.this.startActivity(new Intent(PlacesActivity.this,
                                        Travel.class));
                                PlacesActivity.this.finish();
                                PlacesActivity.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.manage:
                                PlacesActivity.this.startActivity(new Intent(PlacesActivity.this,
                                        Event_list.class));
                                PlacesActivity.this.finish();
                                PlacesActivity.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.add_places:
                                return true;
                            case R.id.all_customers:
                                PlacesActivity.this.startActivity(new Intent(PlacesActivity.this,
                                        Customer_list.class));
                                PlacesActivity.this.finish();
                                PlacesActivity.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });


        temples = (Button) findViewById(R.id.top_news_btn);
        childPark = (Button) findViewById(R.id.corona_virus_btn);
        museum = (Button) findViewById(R.id.sports_btn);
        restaurants = (Button) findViewById(R.id.entertainment_btn);
        hotels = (Button) findViewById(R.id.politics_btn);
        wildlife = (Button) findViewById(R.id.crypto_currency_btn);
        nationalPark = (Button) findViewById(R.id.business_btn);
        island = (Button) findViewById(R.id.food_btn);
        waterfall = (Button) findViewById(R.id.education_btn);
//        social = (Button) findViewById(R.id.social_btn);
//        world = (Button) findViewById(R.id.world_news_btn);
//        india = (Button) findViewById(R.id.india_btn);
//        health = (Button) findViewById(R.id.health_btn);
//        economy = (Button) findViewById(R.id.economy_btn);

        buttonsFunction();

    }
    private void buttonsFunction() {
        temples.setOnClickListener(view -> {
            //init popup
            startActivity(new Intent(PlacesActivity.this, TemplesActivity.class));
        });
        childPark.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, ChildParkActivity.class));
        });
        museum.setOnClickListener(view -> {
            //init popup
            startActivity(new Intent(PlacesActivity.this, MuseumActivity.class));
        });
        restaurants.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, RestaurantsActivity.class));
        });
        hotels.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, HotelsActivity.class));
        });
        wildlife.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, WildlifeActivity.class));
        });
        nationalPark.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, NationalParksActivity.class));
        });
        island.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, IslandsActivity.class));
        });
        waterfall.setOnClickListener(view -> {
            startActivity(new Intent(PlacesActivity.this, WaterfallsActivity.class));
        });
//        social.setOnClickListener(view -> {
//            startActivity(new Intent(PlacesActivity.this, SocialActivity.class));
//        });
//        world.setOnClickListener(view -> {
//            startActivity(new Intent(PlacesActivity.this, WorldNewsActivity.class));
//        });
//        india.setOnClickListener(view -> {
//            startActivity(new Intent(PlacesActivity.this, IndiaActivity.class));
//        });
//        health.setOnClickListener(view -> {
//            startActivity(new Intent(PlacesActivity.this, HealthActivity.class));
//        });
//        economy.setOnClickListener(view -> {
//            startActivity(new Intent(PlacesActivity.this, EconomyActivity.class));
//        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}