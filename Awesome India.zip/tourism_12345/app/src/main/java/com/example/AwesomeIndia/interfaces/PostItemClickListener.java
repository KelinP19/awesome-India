package com.example.AwesomeIndia.interfaces;

import android.view.View;

public interface PostItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
