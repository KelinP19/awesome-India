package com.example.AwesomeIndia.interfaces;

public interface PaymentResultListener {
    void onPaymentSuccess(String s);

    void onPaymentError(int i, String s);
}
