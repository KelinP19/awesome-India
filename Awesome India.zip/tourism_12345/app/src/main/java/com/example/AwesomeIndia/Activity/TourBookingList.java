package com.example.AwesomeIndia.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.AwesomeIndia.Adapters.RequestTourListAdapter;
import com.example.AwesomeIndia.HotelsAPI.HotelModule;
import com.example.AwesomeIndia.HotelsAPI.HotelViewFetchData;
import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.Tour.TourModule;
import com.example.AwesomeIndia.Tour.TourPullData;
import com.example.AwesomeIndia.Tour.TourViewFetchData;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class TourBookingList extends AppCompatActivity implements TourViewFetchData {
    private RecyclerView ListDataView;
    private RequestTourListAdapter mPostsAdapter;
    ArrayList<TourModule> eventArrayList = new ArrayList<>();
    private TourPullData eventPullData;
    private FirebaseFirestore firebaseFirestore;
    private static final String TAG = "ManageEvent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_booking_list);

        ListDataView = findViewById(R.id.EventListView);
        eventPullData = new TourPullData(this,this);
        RecyclerViewMethods();
        eventPullData.onSuccessUpdate(this);

    }
    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new RequestTourListAdapter(this, eventArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }

    @Override
    public void onUpdateSuccess(TourModule message) {
        if(message != null){
            if(message.getEventStatus().equals("pending")){
                TourModule eventModules = new TourModule();
                eventModules.setStudentEmail(message.getStudentEmail());
                eventModules.setEventID(message.getEventID());
                eventModules.setEventDescription(message.getEventDescription());
                eventModules.setEventCategory(message.getEventCategory());
                eventModules.setEventTime(message.getEventTime());
                eventModules.setEventDate(message.getEventDate());
                eventModules.setEventPriceTicket(message.getEventPriceTicket());
                eventModules.setEventImportPicture(message.getEventImportPicture());
                eventModules.setEventStatus(message.getEventStatus());
                eventModules.setToken(message.getToken());
                eventArrayList.add(eventModules);
            }
        }
        mPostsAdapter.notifyDataSetChanged();

    }

    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(TourBookingList.this, message, Toast.LENGTH_LONG).show();
    }


    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.hotel_booking, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {

        if (item.getItemId() == R.id.approved_booking) {
            startActivity(new Intent(TourBookingList.this, ApprovedTourBooking.class));
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}