package com.example.AwesomeIndia.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.AwesomeIndia.R;

public class TempleItemDetailsActivity extends AppCompatActivity {

    private TextView templeName, templeDescription, nameCharacter, places, todo, besttime, famous;
    private ImageView templeImage, backIcon;
    private Button booktour;
    public static Double latitude;
    public static Double longitude;

    String hotelName, hotelPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temple_item_details);

        templeName = findViewById(R.id.temple_name);
        templeImage = findViewById(R.id.temple_image);
        templeDescription = findViewById(R.id.temple_description);
        nameCharacter = findViewById(R.id.nameChar);
        places = findViewById(R.id.temple_places);
        todo = findViewById(R.id.temple_todo);
        besttime = findViewById(R.id.temple_bestTime);
        famous = findViewById(R.id.temple_famous);
        booktour=findViewById(R.id.book_tour);

        booktour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent postDetailActivity = new Intent(TempleItemDetailsActivity.this, BookTourActivity.class);
                postDetailActivity.putExtra("title", hotelName);
                postDetailActivity.putExtra("famous", hotelPrice);
                startActivity(postDetailActivity);
            }
        });

        backIcon = findViewById(R.id.backArrow);
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TempleItemDetailsActivity.this, CustomerPanel.class));
                finish();
            }
        });

        String postImage = getIntent().getExtras().getString("diseaseUrl") ;
        Glide.with(this).load(postImage).into(templeImage);

        String postTitle = getIntent().getExtras().getString("title");
        templeName.setText(postTitle);

        String postDecription = getIntent().getExtras().getString("description");
        templeDescription.setText(postDecription);

        String postChar = getIntent().getExtras().getString("title");
        String arr[] = postChar.split(" ", 2);
        String firstWord = arr[0];
        nameCharacter.setText(firstWord);

        String postStay = getIntent().getExtras().getString("stay");
        places.setText(postStay);

        String postTodo = getIntent().getExtras().getString("todo");
        todo.setText(postTodo);

        String postBestTime = getIntent().getExtras().getString("bestTime");
        besttime.setText(postBestTime);

        String postFamous = getIntent().getExtras().getString("famous");
        famous.setText(postFamous);



    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}