package com.example.AwesomeIndia.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.AwesomeIndia.Adapters.RequestedEventListAdapter;
import com.example.AwesomeIndia.EventAPI.EventModule;
import com.example.AwesomeIndia.EventAPI.EventPullData;
import com.example.AwesomeIndia.EventAPI.EventViewFetchData;
import com.example.AwesomeIndia.R;
import com.example.AwesomeIndia.login.LoginPage;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class AdminPanel extends AppCompatActivity implements EventViewFetchData {

    private RecyclerView ListDataView;
    private RequestedEventListAdapter mPostsAdapter;
    ArrayList<EventModule> eventArrayList = new ArrayList<>();
    private EventPullData eventPullData;
    private FirebaseFirestore firebaseFirestore;
    public String stuName, stuEmail;
    private static final String TAG = "ManageEvent";

    private Button hotel_bookingBTN,tour_bookingBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        hotel_bookingBTN = findViewById(R.id.hotelBookings);
        hotel_bookingBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(AdminPanel.this, HotelBookinsList.class));
                        finish();
                    }
                }
        );
        tour_bookingBTN=findViewById(R.id.TourBookings);
        tour_bookingBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(AdminPanel.this, TourBookingList.class));
                        finish();
                    }
                }
        );


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.requests);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.requests:
                                return true;
                            case R.id.travel:
                                AdminPanel.this.startActivity(new Intent(AdminPanel.this,
                                        Upload.class));
                                AdminPanel.this.finish();
                                AdminPanel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.manage:
                                AdminPanel.this.startActivity(new Intent(AdminPanel.this,
                                        Event_list.class));
                                AdminPanel.this.finish();
                                AdminPanel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.add_places:
                                AdminPanel.this.startActivity(new Intent(AdminPanel.this,
                                        PlacesActivity.class));
                                AdminPanel.this.finish();
                                AdminPanel.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.all_customers:
                                AdminPanel.this.startActivity(new Intent(AdminPanel.this,
                                        Customer_list.class));
                                AdminPanel.this.finish();
                                AdminPanel.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });

        ListDataView = findViewById(R.id.EventListView);
        eventPullData = new EventPullData(this,this);
        RecyclerViewMethods();
        eventPullData.onSuccessUpdate(this);


    }

    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new RequestedEventListAdapter(this, eventArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }

    @Override
    public void onUpdateSuccess(EventModule message) {
        if(message != null){
            if(message.getEventStatus().equals("pending")){
                EventModule eventModules = new EventModule();
                eventModules.setStudentID(message.getStudentID());
                eventModules.setStudentEmail(message.getStudentEmail());
                eventModules.setEventID(message.getEventID());
                eventModules.setEventDescription(message.getEventDescription());
                eventModules.setEventCategory(message.getEventCategory());
                eventModules.setEventTime(message.getEventTime());
                eventModules.setEventDate(message.getEventDate());
                eventModules.setEventPriceTicket(message.getEventPriceTicket());
                eventModules.setEventImportPicture(message.getEventImportPicture());
                eventModules.setEventStatus(message.getEventStatus());
                eventModules.setToken(message.getToken());
                eventArrayList.add(eventModules);
            }
        }
        mPostsAdapter.notifyDataSetChanged();

    }


    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(AdminPanel.this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.admin_actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {

        switch (item.getItemId()){
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), LoginPage.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                break;
            case R.id.queries:
                startActivity(new Intent(AdminPanel.this, AdminResponsesActivity.class));
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

//    //The event handler is being called from the onClick Mehtod that will listen to this function
//    public void onViewCustomerCardViewClick(View view) {
//        Intent intent = new Intent(AdminPanel.this, Customer_list.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }
//
//    //The event handler is being called from the onClick Method that will listen to this function
//    public void onManageEventCardViewClick(View view) {
//        Intent intent = new Intent(AdminPanel.this, ManageEventRequests.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }
//
//
//    public void onViewEventsCardViewClickAdmin(View view) {
//        Intent intent = new Intent(AdminPanel.this, Event_list.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }

//    public void onLogoutAdmin(View view) {
//        Intent intent = new Intent(AdminPanel.this, LoginPage.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }
//
//    public void onAddPlaces(View view) {
//        Intent intent = new Intent(AdminPanel.this, PlacesActivity.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }
}
