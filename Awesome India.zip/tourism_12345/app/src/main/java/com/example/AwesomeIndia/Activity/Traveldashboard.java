package com.example.AwesomeIndia.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.AwesomeIndia.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Traveldashboard extends AppCompatActivity {
    CardView m,m1,m2,m3,m4,m5,m6,m7;
    public String stuTP,stuDegreeField,stuName, stuEmail, stuPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traveldashboard);
        m=findViewById(R.id.maa);
        m1=findViewById(R.id.maa1);
        m2=findViewById(R.id.maa2);
        m3=findViewById(R.id.maa3);
        m4=findViewById(R.id.maa4);
        m5=findViewById(R.id.maa5);
        m6=findViewById(R.id.maa6);
        m7=findViewById(R.id.maa7);

        m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        m7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Traveldashboard.this, Booktravel.class);
                startActivity(i);
            }
        });
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.travel);
        bottomNavigationView.setOnNavigationItemSelectedListener
                (new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.visit:
                                Intent intent3 = new Intent(Traveldashboard.this, CustomerPanel.class);
                                intent3.putExtra("Name",stuName);
                                intent3.putExtra("Email", stuEmail);
                                startActivity(intent3);
                                Traveldashboard.this.finish();
                                Traveldashboard.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.travel:
                                return true;
                            case R.id.stay:
                                Intent intent2 = new Intent(Traveldashboard.this, WhereToStay.class);
                                intent2.putExtra("Name",stuName);
                                intent2.putExtra("Email", stuEmail);
                                startActivity(intent2);
                                Traveldashboard.this.finish();
                                Traveldashboard.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.guide:
//                                CustomerPanel.this.startActivity(new Intent(CustomerPanel.this,
//                                        BookGuide.class));
                                Intent intent = new Intent(Traveldashboard.this, BookGuide.class);
                                intent.putExtra("Tp", stuTP);
                                intent.putExtra("Degree", stuDegreeField);
                                intent.putExtra("Name",stuName);
                                intent.putExtra("Email", stuEmail);
                                intent.putExtra("PhoneNo", stuPhoneNumber);
                                startActivity(intent);
                                Traveldashboard.this.finish();
                                Traveldashboard.this.overridePendingTransition(0, 0);
                                return true;
                            case R.id.query:
                                Intent intent1 = new Intent(Traveldashboard.this, AskQuery.class);
                                intent1.putExtra("Tp", stuTP);
                                intent1.putExtra("Name",stuName);
                                intent1.putExtra("Email", stuEmail);
                                intent1.putExtra("PhoneNo", stuPhoneNumber);
                                startActivity(intent1);
                                Traveldashboard.this.finish();
                                Traveldashboard.this.overridePendingTransition(0, 0);
                                return true;
                        }
                        return false;
                    }
                });

    }
}