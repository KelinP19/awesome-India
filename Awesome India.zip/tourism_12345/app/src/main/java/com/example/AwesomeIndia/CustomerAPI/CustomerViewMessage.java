package com.example.AwesomeIndia.CustomerAPI;

public interface CustomerViewMessage {

    void onUpdateFailure(String message);
    void onUpdateSuccess(String message);

}
