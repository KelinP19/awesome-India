package com.example.AwesomeIndia.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.AwesomeIndia.Adapters.HotelsListAdapter;
import com.example.AwesomeIndia.HotelsAPI.HotelModule;
import com.example.AwesomeIndia.HotelsAPI.HotelPullData;
import com.example.AwesomeIndia.HotelsAPI.HotelViewFetchData;
import com.example.AwesomeIndia.R;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class CustomerHotelList extends AppCompatActivity implements HotelViewFetchData {

    private RecyclerView ListDataView;
    private HotelsListAdapter mPostsAdapter;
    ArrayList<HotelModule> eventArrayList = new ArrayList<>();
    private HotelPullData eventPullData;
    private FirebaseFirestore firebaseFirestore;
    private static final String TAG = "ManageEvent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_hotel_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        ListDataView = findViewById(R.id.EventListView);
        eventPullData = new HotelPullData(this,this);
        RecyclerViewMethods();
        eventPullData.onSuccessUpdate(this);
    }

    private void RecyclerViewMethods() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        ListDataView.setLayoutManager(manager);
        ListDataView.setHasFixedSize(true);
        mPostsAdapter = new HotelsListAdapter(this, eventArrayList);
        ListDataView.setAdapter(mPostsAdapter);
        ListDataView.invalidate();

    }

    @Override
    public void onUpdateSuccess(HotelModule message) {
        if(message != null){
            if(message.getEventStatus().equals("pending")){
                HotelModule eventModules = new HotelModule();
                eventModules.setStudentEmail(message.getStudentEmail());
                eventModules.setEventID(message.getEventID());
                eventModules.setEventDescription(message.getEventDescription());
                eventModules.setEventCategory(message.getEventCategory());
                eventModules.setEventTime(message.getEventTime());
                eventModules.setEventDate(message.getEventDate());
                eventModules.setEventPriceTicket(message.getEventPriceTicket());
                eventModules.setEventImportPicture(message.getEventImportPicture());
                eventModules.setEventStatus(message.getEventStatus());
                eventModules.setToken(message.getToken());
                eventArrayList.add(eventModules);
            }
        }
        mPostsAdapter.notifyDataSetChanged();

    }


    @Override
    public void onUpdateFailure(String message) {

        Toast.makeText(CustomerHotelList.this, message, Toast.LENGTH_LONG).show();
    }

    public void goToBookGuide(View view) {
        startActivity(new Intent(CustomerHotelList.this, WhereToStay.class));
        finish();
    }
    
}